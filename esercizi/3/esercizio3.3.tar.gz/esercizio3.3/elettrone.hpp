#ifndef elettrone_hpp
#define elettrone_hpp
#include "particella.hpp"
class Elettrone : public Particella{
public:
    Elettrone();
    void Print() const;
};
#endif
