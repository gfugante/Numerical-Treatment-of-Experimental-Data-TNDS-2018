#ifndef _funzioni_hpp_
#define _funzioni_hpp_

double Modulo(double x);
double Modulo(double a, double b);
double Modulo(double *vettore, int dimensione);

#endif