#ifndef _funzionebase_h_
#define _funzionebase_h_

class FunzioneBase {

public:
	virtual double Eval(double x) const =0;

};
#endif
