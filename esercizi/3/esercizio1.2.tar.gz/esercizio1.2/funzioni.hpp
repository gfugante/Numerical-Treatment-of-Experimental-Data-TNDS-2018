#ifndef funzioni_hpp
#define funzioni_hpp
int Conta();
void Stampa(double *p, int limite);
void Carica(double *p, int limite);
void ScambioPD(double *p, int limite);
#endif /* funzioni_hpp */
