#ifndef _funzioni_hpp_
#define _funzioni_hpp_

int numeroScambi();
void scambiabyvalue(double a, double b);
void scambiabyreference(double &a, double &b);
void scambiabypointer(double *a, double *b);

#endif