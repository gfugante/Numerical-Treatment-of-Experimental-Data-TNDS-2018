#ifndef _funzioni_hpp_
#define _funzioni_hpp_

double somma(double vettore[], int limite);
double sommaquadratura(double vettore[], int limite);

#endif