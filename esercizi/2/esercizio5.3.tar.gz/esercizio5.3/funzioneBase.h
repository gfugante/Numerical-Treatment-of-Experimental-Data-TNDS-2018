#ifndef _FUNZIONEBASE_H_
#define _FUNZIONEBASE_H_

using namespace std;

class funzioneBase{
	public:
		virtual double eval(double x) const =0;
};

#endif
