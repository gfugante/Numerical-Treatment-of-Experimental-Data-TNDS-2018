void scambiabyvalue (double, double);
void scambiabyreference (double &, double &);
void scambiabypointer (double * , double *);
int numeroscambi();
