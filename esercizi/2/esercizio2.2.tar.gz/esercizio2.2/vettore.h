struct vettore read(unsigned int, const char*);
void selection_sort(const struct vettore);
void stampa1(const struct vettore);
void stampa2(const struct vettore);
