#include <iostream>
#include "segno.h"
using namespace std;

double sign(double t){
	if(t<0)
		return -1;
	else
		return 1;
}
