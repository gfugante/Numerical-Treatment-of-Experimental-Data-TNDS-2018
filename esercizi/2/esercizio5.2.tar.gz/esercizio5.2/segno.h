double sign(double);
