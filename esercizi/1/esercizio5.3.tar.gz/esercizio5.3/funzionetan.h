#ifndef _FUNZIONE_H_
#define _FUNZIONE_H_

#include <cmath>
#include "funzionebase.h"

class xtan:public funzioneBase {
	public:
	virtual double Eval(double x) const;
	};

#endif
