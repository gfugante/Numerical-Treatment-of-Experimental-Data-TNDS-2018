

#include "funzionetan.h"

double xtan::Eval(double x) const{
	return sin(x)-x*cos(x);
}
		


