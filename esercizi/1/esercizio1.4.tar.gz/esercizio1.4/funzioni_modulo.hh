#include <cmath>
double modulo (double);
double modulo (double, double);
double modulo (double*, int);
