#include <iostream> 
#include <fstream>
using namespace std;


void scambia3(double*,double*);
