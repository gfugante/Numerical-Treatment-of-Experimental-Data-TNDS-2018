void scambia3(double*x,double*y){
	double z=*x;
	*x=*y;
	*y=z;

	return;
}
