#ifndef _SIGNFUNCTION_H_
#define _SIGNFUNCTION_H

int sign (double x);

#endif
