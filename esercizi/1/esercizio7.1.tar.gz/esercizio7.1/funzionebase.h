#ifndef _FUNZIONEBASE_H_
#define _FUNZIONEBASE_H_

class funzioneBase{
	public:
		virtual double Eval(double x) const=0;
		
};

#endif
