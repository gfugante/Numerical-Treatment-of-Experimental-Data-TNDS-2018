double media (double*, int);
double varianza (double*, int);
